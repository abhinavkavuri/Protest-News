(Prerequesites for event extraction)

If files found corrupted due to ultra compression !!

-> Stanford NER 2018.10.16 = https://nlp.stanford.edu/software/CRF-NER.shtml
-> TFIDF Vector Pickle file = mailto:akavuri@buffalo.edu
